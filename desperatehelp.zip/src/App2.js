import logo from './logo.svg';
import './App.css';
import {ethers} from "ethers";
import Header from './components/Header/Header';
import lillyabi_ from './LillyAbi.json';
import rankingabi_ from './rankingAbi.json';
import { useEffect, useState } from "react";

let provider ;
let signer;
let address;
let rank;
var leaderboard;
var token;
var address_;
var score_;
var user_;

let position_ = 0;


const ranking_smart = "0xBF6c173dC622d33929714490c333F0f7131353EC";


const contractConnection = async  () => {

  await window.ethereum.enable();
  const provider = new ethers.providers.Web3Provider(window.ethereum);
  const signer = await provider.getSigner();
  const address = await signer.getAddress();
  const rank = new ethers.Contract( ranking_smart , rankingabi_ , signer );
  console.log(signer);
  console.log(rank);


 };





const sign_rank = async () => {

  const score = await rank.add_member("Kilo1", "33", "0xD5D7f7cdda240aE62d6a0489E63300a0C0F29B0e");
  console.log(score);
  return score;

}


const obtain_rank2 = function(){
      console.log(rank);
       address_ = rank.registro("0") ;

       console.log(address_);



}


const obtain_load = async() =>{
    provider = new ethers.providers.Web3Provider(window.ethereum);
  const rank = new ethers.Contract( ranking_smart ,   JSON.stringify(rankingabi_) , provider );
  console.log(rank);
  let leaderboard__ = await rank.leaderboard(0);

}

const get_all_address = async() =>{
  const all_address = rank.see_all_address();
  return all_address;

}

const print = function(){
  console.log("provider: " + provider);
  console.log("address: " + address);
  console.log("rank: " + rank);


}




const countdown_ = setInterval(timer,500)

function timer2(){
  return(

    <div>
        {countdown_}
    </div>
  );
}

function timer(){
  var countDownDate = new Date("Aug 15, 2022 15:30:22");
  //var countDownDate__ = new Date("3 march 2015");
  //var countDownDate_ = new Date( "Jan 5, 2024 15:37:25").getTime();




    // Get today's date and time
    var now = new Date().getTime();

    // Find the distance between now and the count down date
    var distance = countDownDate - now;

    // Time calculations for days, hours, minutes and seconds
    var days = Math.floor(distance / (1000 * 60 * 60 * 24));
    var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
    var seconds = Math.floor((distance % (1000 * 60)) / 1000);

      ///console.log(distance);
    return(

      <div>
        {countDownDate.toLocaleString()};
        <div>
          {"D" + days + " H" + hours + " M" + minutes +" S" + seconds};
        </div>

        <div> {distance.toLocaleString()}  </div>
      </div>


    );



  }



function App() {



  return (




    <div className="App">
        <div>

        </div>


        <div>
            <Header/>
        </div>

        <div className = "span">

        </div>


        <button className = "glow-on-hover" onClick={obtain_rank2}>
          get data
        </button>


        <div className = "span">

        </div>


        <button className = "glow-on-hover" onClick= {contractConnection} >
          contract connection
        </button>

        <div className = "span">

        </div>


        <button className = "glow-on-hover" onClick= {sign_rank} >
          Add rank test
        </button>

        <div className = "span">

        </div>

        <button className = "glow-on-hover" onClick= {get_all_address } >
          All Address
        </button>

        <div className = "span">

        </div>

        <div>


        </div>

        <div className = "span"> </div>

        <button className = "glow-on-hover" onClick= {print} >
          Print
        </button>





    </div>
  );
}

export default App;
