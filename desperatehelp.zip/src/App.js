import logo from './logo.svg';
import './App.css';
import {ethers} from "ethers";
import Header from './components/Header/Header';
import { useEffect, useState } from "react";
import rankingabi_ from './rankingAbi.json';




var rank;
var leaderboard;
var token;
var address_;
var score_;
var user_;

let position_ = 0;

var address_ =  "0xF3cf9A93649E8DF48e96d453A38494e623931083";

var provider;
var signer;
var address;



const enable = async () =>{
  await window.ethereum.enable();
  provider = new ethers.providers.Web3Provider(window.ethereum);
  signer = await provider.getSigner();
  address = await signer.getAddress();

  console.log(provider);

  return provider, signer, address
}


const contractConnection2 = async  () => {

  rank = new ethers.Contract( address_, rankingabi_ ,signer);
  console.log(rank);
  return rank;


}



const registro = async() =>
  {


    const gg = await rank.viewregistro(1);
    console.log(gg);

  }


const registrovariable = async() =>
    {


      const reg=  await rank.registro(1);
      console.log(reg);

    }


const addmember = async() => {

    rank.compile_registro("pluto");

  }


const print = function () {
  console.log("provider:");
  console.log(provider);
  console.log("signer:");
  console.log(signer);
  console.log("rank:");
  console.log(rank);


}

function App(){


    return(
      <div>


              <div>
                  <button onClick={print}> print </button>


              </div>


              <div>

                  <button onClick = {enable}> Enable </button>

              </div>





              <div>

              <button onClick = {contractConnection2}> contractconnection </button>


              </div>


              <div>

              <button onClick = {registro}> registro</button>


              </div>


              <div>

                <button onClick = {addmember}> add member </button>


              </div>

              <div>
                  <button onClick = {registrovariable}> registrovariable </button>


              </div>

    </div>
)


}

export default App;
